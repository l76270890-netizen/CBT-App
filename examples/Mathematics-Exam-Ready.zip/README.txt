MATHEMATICS EXAM - BULK QUESTION UPLOAD

Upload this ZIP directly in the Admin > Questions > Bulk import section.
Select the exam first, choose this ZIP, then choose "Upload ZIP and import questions".

ZIP contents:
- questions.csv: five question rows using the exact columns below
- images/triangle.png, images/angles.png, images/circle.png: question diagrams
- README.txt: these instructions

CSV columns (in order):
subject,question,optionA,optionB,optionC,optionD,correctAnswer,explanation,imageUrl

For an image, imageUrl must be the relative ZIP path, for example:
images/triangle.png
Leave imageUrl empty for a question without an image. Correct answers must be A, B, C, or D.
The CSV is UTF-8 encoded so mathematical symbols and degree signs display correctly.
